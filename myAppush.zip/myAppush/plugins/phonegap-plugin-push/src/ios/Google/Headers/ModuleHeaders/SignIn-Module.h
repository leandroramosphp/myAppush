#if defined(__has_include)
# if __has_include(<Google/SignIn.h>)
#  include <Google/SignIn.h>
# endif
#endif
